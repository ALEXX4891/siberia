-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Июл 08 2024 г., 14:32
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `wwserver_siberia`
--

-- --------------------------------------------------------

--
-- Структура таблицы `apartments`
--
-- Создание: Июл 08 2024 г., 05:37
-- Последнее обновление: Июл 08 2024 г., 05:44
--

DROP TABLE IF EXISTS `apartments`;
CREATE TABLE `apartments` (
  `id` int(11) NOT NULL,
  `complex` varchar(256) NOT NULL,
  `stage` int(11) NOT NULL,
  `house` int(11) NOT NULL,
  `apartment` int(11) NOT NULL,
  `image` varchar(256) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `number_of_rooms` int(11) DEFAULT NULL,
  `area` decimal(5,2) NOT NULL,
  `balcony` tinyint(1) NOT NULL,
  `dressing_room` tinyint(1) NOT NULL,
  `undershirt_2` tinyint(1) NOT NULL,
  `undershirt_3` tinyint(1) NOT NULL,
  `guest_bathroom` tinyint(1) NOT NULL,
  `kitchen_living_room` tinyint(1) NOT NULL,
  `studio` tinyint(1) NOT NULL,
  `commerce` tinyint(1) NOT NULL,
  `floor` int(11) NOT NULL,
  `entrance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='таблица квартир';

--
-- Дамп данных таблицы `apartments`
--

INSERT INTO `apartments` (`id`, `complex`, `stage`, `house`, `apartment`, `image`, `price`, `number_of_rooms`, `area`, `balcony`, `dressing_room`, `undershirt_2`, `undershirt_3`, `guest_bathroom`, `kitchen_living_room`, `studio`, `commerce`, `floor`, `entrance`) VALUES
(115, 'Сосновый', 1, 1, 1, 'kv-1.jpg', '3700000.00', 1, '37.00', 1, 0, 0, 0, 0, 1, 0, 0, 1, 1),
(116, 'Сосновый', 1, 1, 2, 'kv-2.jpg', '3700000.00', 1, '37.00', 1, 1, 0, 0, 0, 1, 0, 0, 1, 1),
(117, 'Сосновый', 1, 1, 3, 'kv-3.jpg', '3900000.00', 1, '39.00', 1, 0, 0, 0, 0, 1, 0, 0, 1, 1),
(118, 'Сосновый', 1, 1, 4, 'kv-4.jpg', '4000000.00', 1, '40.00', 1, 0, 0, 0, 0, 1, 0, 0, 1, 1),
(119, 'Сосновый', 1, 1, 5, 'kv-5.jpg', '4200000.00', 1, '42.00', 1, 0, 0, 0, 0, 1, 0, 0, 1, 1),
(120, 'Сосновый', 1, 1, 6, 'kv-6.jpg', '4200000.00', 1, '42.00', 1, 0, 1, 0, 0, 1, 0, 0, 1, 1),
(121, 'Сосновый', 1, 1, 7, 'kv-7.jpg', '4200000.00', 1, '42.00', 1, 0, 0, 0, 0, 1, 0, 0, 1, 1),
(122, 'Сосновый', 1, 1, 8, 'kv-8.jpg', '5500000.00', 2, '55.00', 1, 0, 1, 0, 0, 0, 0, 0, 1, 1),
(123, 'Сосновый', 1, 1, 9, 'kv-9.jpg', '6000000.00', 2, '60.00', 1, 1, 0, 0, 0, 0, 0, 0, 1, 1),
(124, 'Сосновый', 1, 1, 10, 'kv-10.jpg', '4300000.00', 2, '43.00', 1, 0, 1, 0, 0, 1, 0, 0, 1, 1),
(125, 'Сосновый', 1, 1, 11, 'kv-11.jpg', '5600000.00', 1, '56.00', 1, 0, 1, 0, 0, 1, 0, 0, 1, 1),
(126, 'Сосновый', 1, 1, 12, 'kv-12.jpg', '5900000.00', 2, '59.00', 1, 0, 0, 1, 0, 1, 0, 0, 1, 1),
(127, 'Сосновый', 1, 1, 13, 'kv-13.jpg', '8000000.00', 3, '80.00', 1, 0, 1, 0, 0, 1, 0, 0, 1, 1),
(128, 'Сосновый', 1, 1, 14, 'kv-14.jpg', '7400000.00', 3, '74.00', 1, 0, 1, 0, 1, 1, 0, 0, 1, 1),
(129, 'Сосновый', 1, 1, 15, 'kv-15.jpg', '5800000.00', 3, '58.00', 1, 1, 0, 0, 0, 1, 0, 0, 1, 1),
(130, 'Сосновый', 1, 1, 16, 'kv-16.jpg', '5900000.00', 3, '59.00', 1, 0, 0, 0, 0, 1, 0, 0, 1, 1),
(131, 'Сосновый', 1, 1, 17, 'kv-17.jpg', '6300000.00', 3, '63.00', 1, 0, 1, 0, 0, 1, 0, 0, 1, 1),
(132, 'Сосновый', 1, 1, 18, 'kv-18.jpg', '6300000.00', 3, '63.00', 1, 1, 1, 0, 0, 1, 0, 0, 1, 1),
(133, 'Сосновый', 1, 1, 19, 'kv-19.jpg', '2600000.00', 1, '26.00', 1, 0, 0, 0, 0, 1, 1, 0, 1, 1),
(134, 'Сосновый', 1, 1, 20, 'kv-20.jpg', '2600000.00', 1, '26.00', 1, 0, 0, 0, 0, 1, 1, 0, 1, 1),
(135, 'Сосновый', 1, 1, 21, 'kv-21.jpg', '3200000.00', 1, '32.00', 1, 0, 0, 0, 0, 1, 1, 0, 1, 1),
(136, 'Сосновый', 1, 1, 22, 'kv-22.jpg', '3200000.00', 1, '32.00', 1, 0, 0, 0, 0, 1, 1, 0, 1, 1),
(137, 'Сосновый', 1, 1, 100, 'kom-1.jpg', '30200000.00', 6, '151.00', 0, 0, 0, 0, 0, 0, 0, 1, 1, 1),
(138, 'Сосновый', 1, 1, 101, 'kom-2.jpg', '41800000.00', 9, '209.00', 0, 0, 0, 0, 0, 0, 0, 1, 1, 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `apartments`
--
ALTER TABLE `apartments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `apartments`
--
ALTER TABLE `apartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
